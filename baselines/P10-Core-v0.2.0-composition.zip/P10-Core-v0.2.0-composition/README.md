# P10-Core v0.2.0-composition

This release adds a bounded conditional-composition layer on top of the frozen
`v0.1.0-four-evidence` seed. The original checker-soundness theorem and its
trust boundary are copied byte-for-byte and remain unchanged.

## Typed chain

The concrete chain has four stage types and three transitions:

```text
Stage0 (claim, evidence)
  → Stage1 (formal target)
  → Stage2 (checked evidence)
  → Stage3 (certificate, verdict)
```

Each transition has:

- an executable local checker;
- a semantic `ContractRelᵢ`;
- a `FidelityRelᵢ` preserving the claim/evidence identity;
- a proved `LocalSoundᵢ` obligation;
- a proved `Fidelityᵢ` obligation;
- an explicit transition certificate with presence, contract, and fidelity
  flags.

## Main theorems

`conditionalComposition` proves:

```lean
CompositionObligations D P →
Composable D P τ1 τ2 τ3 x0 x1 x2 x3 →
GlobalSupport P x0 x1 x2 x3
```

`CompositionObligations` is exactly the bounded conjunction of
`LocalSound1..3` and `Fidelity1..3`. `compositionObligations` proves the entire
conjunction for this instance, so `fourEvidenceComposes` has no opaque
soundness premise.

`GlobalSupport` ends in the existing declarative protocol judgement:

```lean
Supports (semantics P) x3.evidence x3.claim x3.certificate x3.verdict
```

It contains no `Truth_M` predicate and makes no semantic-truth claim.

## Adversarial theorems

- `missingCertificateCannotCompose`
- `failedContractCannotCompose`
- `brokenFidelityCannotCompose`

Each proves that the adversarial chain cannot inhabit `CompositionWitness`,
which pairs successful local checks with `GlobalSupport`.

## Trust boundary

There are no `sorry`, `admit`, user-declared axioms, or opaque local-soundness
assumptions. `DigestModel.injective` remains the same explicit domain premise as
in the seed release. See [AXIOM_AUDIT.md](AXIOM_AUDIT.md) for Lean's exact
`#print axioms` results.

## Build

Pinned toolchain: Lean 4.34.0.

```sh
lake build
```
